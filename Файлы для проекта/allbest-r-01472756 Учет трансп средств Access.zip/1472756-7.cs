﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace CarsManagment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //функция загрузки транспортных средств в таблицу
        private void loadCars()
        {
            //очищаем комбобоксы от предыдущих данных
            comboBox1.Items.Clear();
            comboBox8.Items.Clear();
            comboBox5.Items.Clear();

            //подключаемся  к бд
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            myOleDbConnection.Open();
            //запрос
            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter("SELECT id, marka as `Марка`, naimenovanie as `Модель`,"
               + " kategor as `Категория`, god as `Год выпуска`, moshnost as `Мощность`, objem as `Объем двигателя`, rashod as `Расход топлива` "
               +  "   FROM cars WHERE use = true", myOleDbConnection);
            DataTable dataTable = new DataTable();
            dbAdapter1.Fill(dataTable);
            //загружаем данные в таблицу
            dataGridView1.DataSource = dataTable;

            //загружаем данные в комбобоксы, номера транспортных средств
            foreach (DataRow row in dataTable.Rows)
            {
                string TableName = row["id"].ToString();
                comboBox1.Items.Add(TableName);
                comboBox8.Items.Add(TableName);
                comboBox5.Items.Add(TableName);
            }

            myOleDbConnection.Close();
        }

        //загрузка компаний занимающихся техническим обслуживанием
        private void loadCompanies()
        {
            //очищаем комбобоксы от предыдущих данных
            comboBox6.Items.Clear();
            comboBox7.Items.Clear();

            //подключаемся  к бд
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            myOleDbConnection.Open();
            //загружаем все компании, с которыми есть сотрудничество
            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter("SELECT id, naimenov as `Наименование`, email as `Email`,"
               + " telephon as `Телефон`, nachalo as `Начало сотрудничества`, srok as `Окончание сотрудничества` "
               + "   FROM company WHERE use = true", myOleDbConnection);
            DataTable dataTable = new DataTable();
            dbAdapter1.Fill(dataTable);
            dataGridView2.DataSource = dataTable;

            //заполняем комбобоксы номерами компаний
            foreach (DataRow row in dataTable.Rows)
            {
                string TableName = row["id"].ToString();
                comboBox6.Items.Add(TableName);
                comboBox7.Items.Add(TableName);
            }

            myOleDbConnection.Close();
        }

        //загрузка водителей
        private void loadDrivers()
        {
            comboBox4.Items.Clear();
            comboBox9.Items.Clear();

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            myOleDbConnection.Open();
            //загружаем водителей, которые на данный момент работают
            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter("SELECT id, fio as `ФИО`, vozrast as `Возраст`,"
               + " telephon as `Телефон`, stag as `Стаж` "
               + "   FROM voditel WHERE use = true", myOleDbConnection);
            DataTable dataTable = new DataTable();
            dbAdapter1.Fill(dataTable);
            dataGridView3.DataSource = dataTable;

            foreach (DataRow row in dataTable.Rows)
            {
                string TableName = row["id"].ToString();
                comboBox4.Items.Add(TableName);
                comboBox9.Items.Add(TableName);
            }

            myOleDbConnection.Close();
        }

        //загружаем список заявок на техническое обслуживание транспортных средств
        private void loadTech()
        {
            dataGridView4.DataSource = null;

            loadCars();
            loadCompanies();

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            myOleDbConnection.Open();
            //загружаем все заявки, которые удовлетворяют временному ограничению
            string command = "SELECT cars.id as `id транспортного средства`, "
               + " obslugivanie.data as `дата последнего обслуживания`,"
               + " cars.marka+cars.naimenovanie as `Транспортное средство`,"
               + " company.naimenov as `Компания` "
               + " FROM obslugivanie,cars,company WHERE obslugivanie.transport=cars.id AND obslugivanie.kompanija=company.id "
               + " AND cars.use=true AND company.use=true AND obslugivanie.data>#" +dateTimePicker3.Value.Day.ToString()+ "/" +
                    dateTimePicker3.Value.Month.ToString() + "/" + dateTimePicker3.Value.Year.ToString() + "# ORDER BY obslugivanie.data";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);
          
            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter(myoledbcommand);
            DataTable dataTable = new DataTable();
            dbAdapter1.Fill(dataTable);
            dataGridView4.DataSource = dataTable;        

            myOleDbConnection.Close();
        }

        //загрузка заявок на использование транспортных средств
        private void loadUsage()
        {
            loadCars();
            loadDrivers();

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            myOleDbConnection.Open();
            //загрузка заявок на указанный день
            string command = "SELECT ispolzovanie.id as `id заявки`, "
               + " ispolzovanie.dataN as `Время использования`,"
               + " ispolzovanie.dataF as `До`,"
               + " cars.marka+cars.naimenovanie as `Транспортное средство`,"
               + " voditel.fio as `Водитель` "
               + " FROM ispolzovanie,cars,voditel WHERE ispolzovanie.transport=cars.id AND ispolzovanie.voditel=voditel.id "
               + " AND cars.use=true AND voditel.use=true AND ispolzovanie.dataN=#" + dateTimePicker5.Value.Day.ToString() + "/" +
                    dateTimePicker5.Value.Month.ToString() + "/" + dateTimePicker5.Value.Year.ToString() + "# ";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter(myoledbcommand);
            DataTable dataTable = new DataTable();
            dbAdapter1.Fill(dataTable);
            dataGridView5.DataSource = dataTable;

            myOleDbConnection.Close();
        }

        //добавление нового автомобиля
        private void buttonAddTransport_Click(object sender, EventArgs e)
        {
            if (textBoxMarka.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите название марки");
                return;
            }

            if (textBoxName.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите наименование модели");
                return;
            }

            if (comboBoxCategory.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите категорию");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "INSERT INTO cars(marka,naimenovanie,kategor,god,moshnost,objem,rashod,use) values (@marka,@naimenovanie,@kategor,@god,@moshnost,@objem,@rashod,true)";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            myoledbcommand.Parameters.Add("@marka", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@marka"].Value = textBoxMarka.Text;

            myoledbcommand.Parameters.Add("@naimenovanie", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@naimenovanie"].Value = textBoxName.Text;

            myoledbcommand.Parameters.Add("@kategor", OleDbType.VarChar, 1);
            myoledbcommand.Parameters["@kategor"].Value = comboBoxCategory.Text;

            myoledbcommand.Parameters.Add("@god", OleDbType.Integer);
            myoledbcommand.Parameters["@god"].Value = Convert.ToInt32(comboBoxYear.Text);

            myoledbcommand.Parameters.Add("@moshnost", OleDbType.Integer);
            myoledbcommand.Parameters["@moshnost"].Value = numericUpDownPower.Value;

            myoledbcommand.Parameters.Add("@objem", OleDbType.Single);
            myoledbcommand.Parameters["@objem"].Value = numericUpDownV.Value;

            myoledbcommand.Parameters.Add("@rashod", OleDbType.Single);
            myoledbcommand.Parameters["@rashod"].Value = numericUpDownRashod.Value; 


            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadCars();
        }

        //загрузка формы - вызов функции загрузки списка автомобилей
        private void Form1_Load(object sender, EventArgs e)
        {
            loadCars();
            
        }

        //функция снятия с учета тр. средства
        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете номер транспортного средства, которое собираетесь снять с учета");
                return;
            }


            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "UPDATE cars SET use=false WHERE id=@id";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            
            myoledbcommand.Parameters.Add("@id", OleDbType.Integer);
            myoledbcommand.Parameters["@id"].Value = Convert.ToInt32(comboBox1.Text);



            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadCars();
        }

        //добавление новой обслуживающей компании
        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox6.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете номер обслуживающей компании, с которой собираетесь расторгнуть договор");
                return;
            }


            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "UPDATE company SET use=false WHERE id=@id";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);


            myoledbcommand.Parameters.Add("@id", OleDbType.Integer);
            myoledbcommand.Parameters["@id"].Value = Convert.ToInt32(comboBox6.Text);
            
            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadCompanies();
        }

        //добавление новой обслуживающей компании
        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox10.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите наименование компании");
                return;
            }

            if (textBox9.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите наименование модели");
                return;
            }

            if (textBox8.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите категорию");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "INSERT INTO company(naimenov,email,telephon,nachalo,srok,use) values (@naimenov,@email,@telephon,@nachalo,@srok,true)";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            myoledbcommand.Parameters.Add("@naimenov", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@naimenov"].Value = textBox10.Text;

            myoledbcommand.Parameters.Add("@email", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@email"].Value = textBox9.Text;

            myoledbcommand.Parameters.Add("@telephon", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@telephon"].Value = textBox8.Text;

            myoledbcommand.Parameters.Add("@nachalo", OleDbType.Date);
            myoledbcommand.Parameters["@nachalo"].Value = dateTimePicker1.Value;

            myoledbcommand.Parameters.Add("@srok", OleDbType.Date);
            myoledbcommand.Parameters["@srok"].Value = dateTimePicker2.Value;
            

            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadCompanies();
        }

        //удаление водителя
        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox4.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете номер водителя, с которым собираетесь расторгнуть договор");
                return;
            }


            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "UPDATE voditel SET use=false WHERE id=@id";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);


            myoledbcommand.Parameters.Add("@id", OleDbType.Integer);
            myoledbcommand.Parameters["@id"].Value = Convert.ToInt32(comboBox4.Text);

            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadDrivers();
        }

        //добавление водителя
        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите ФИО");
                return;
            }

            if (textBox3.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала введите номер телефона");
                return;
            }

            bool fnd = false;
            for(int i=0; i<checkedListBox1.Items.Count; i++)
                if (checkedListBox1.GetItemChecked(i))
                {
                    fnd = true;
                    break;
                }

            if (!fnd)
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете хотя бы одну категорию");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "INSERT INTO voditel(fio,vozrast,telephon,stag,use) values (@fio,@vozrast,@telephon,@stag,true)";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            myoledbcommand.Parameters.Add("@fio", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@fio"].Value = textBox5.Text;

            myoledbcommand.Parameters.Add("@vozrast", OleDbType.Date);
            myoledbcommand.Parameters["@vozrast"].Value = dateTimePicker8.Value;

            myoledbcommand.Parameters.Add("@telephon", OleDbType.VarChar, 100);
            myoledbcommand.Parameters["@telephon"].Value = textBox3.Text;

            myoledbcommand.Parameters.Add("@stag", OleDbType.Integer);
            myoledbcommand.Parameters["@stag"].Value = numericUpDown4.Value;


            //получаем id вставленной записи
            OleDbDataAdapter dbAdapter1 = new OleDbDataAdapter("SELECT TOP 1 id FROM voditel ORDER BY id DESC", myOleDbConnection);
            DataTable dataTable = new DataTable();
            dbAdapter1.Fill(dataTable);

            int id = 0;
            foreach (DataRow row in dataTable.Rows)
            {
                id = Convert.ToInt32(row["id"].ToString());
            }


            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();

            char s = 'a';
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
                if (checkedListBox1.GetItemChecked(i))
                {
                    //создание запроса с параметрами
                    command = "INSERT INTO kategorii(voditel,kategorija) values (@voditel,@kategorija,true)";
                    myoledbcommand = new OleDbCommand(command, myOleDbConnection);

                    myoledbcommand.Parameters.Add("@voditel", OleDbType.Integer);
                    myoledbcommand.Parameters["@voditel"].Value = id;

                    myoledbcommand.Parameters.Add("@kategorija", OleDbType.VarChar, 1);
                    myoledbcommand.Parameters["@kategorija"].Value = s;

                    s++;
                }
                       

            myOleDbConnection.Close();
            

            loadDrivers();
        }

        //обработчик переключения вкладок - загрузка новых данных
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
                loadCars();
            else if (tabControl1.SelectedIndex == 1)
                loadCompanies();
            else if (tabControl1.SelectedIndex == 2)
                loadDrivers();
            else if (tabControl1.SelectedIndex == 3)
                loadTech();
            else if (tabControl1.SelectedIndex == 4)
                loadUsage();
        }

        //подача заявки на тех обслуживание
        private void button8_Click(object sender, EventArgs e)
        {
            if (comboBox8.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете номер транспортного средства");
                return;
            }

            if (comboBox7.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете номер обслуживающей компании");
                return;
            }

            if (textBox6.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала укажите причину заявки");
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "INSERT INTO obslugivanie(data,transport,kompanija,prichina) values (@data,@transport,@kompanija,@prichina)";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            myoledbcommand.Parameters.Add("@data", OleDbType.Date);
            myoledbcommand.Parameters["@data"].Value = dateTimePicker4.Value;

            myoledbcommand.Parameters.Add("@transport", OleDbType.Integer);
            myoledbcommand.Parameters["@transport"].Value = Convert.ToInt32(comboBox8.Text);

            myoledbcommand.Parameters.Add("@kompanija", OleDbType.Integer);
            myoledbcommand.Parameters["@kompanija"].Value = Convert.ToInt32(comboBox7.Text);

            myoledbcommand.Parameters.Add("@prichina", OleDbType.VarChar, 250);
            myoledbcommand.Parameters["@prichina"].Value = textBox6.Text;
            
            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadTech();
        }

        //загрузка новый заявок на тех обслуживание
        private void button9_Click(object sender, EventArgs e)
        {
            loadTech();
        }

        //загрузка новый заявок на использование тр средств
        private void button7_Click(object sender, EventArgs e)
        {
            loadUsage();
        }

        //подача заявки на использование транспортного средства
        private void button10_Click(object sender, EventArgs e)
        {
            if (comboBox9.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете водителя");
                return;
            }

            if (comboBox5.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Сначала выберете транспортное средство");
                return;
            }


            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database.accdb";
            OleDbConnection myOleDbConnection = new OleDbConnection(connectionString);

            //создание запроса с параметрами
            string command = "INSERT INTO ispolzovanie(dataN,dataF,voditel,transport) values (@dataN,@dataF,@voditel,@transport)";
            OleDbCommand myoledbcommand = new OleDbCommand(command, myOleDbConnection);

            myoledbcommand.Parameters.Add("@dataN", OleDbType.Date);
            myoledbcommand.Parameters["@dataN"].Value = dateTimePicker6.Value;

            myoledbcommand.Parameters.Add("@dataF", OleDbType.Date);
            myoledbcommand.Parameters["@dataF"].Value = dateTimePicker7.Value;

            myoledbcommand.Parameters.Add("@voditel", OleDbType.Integer);
            myoledbcommand.Parameters["@voditel"].Value = Convert.ToInt32(comboBox9.Text);

            myoledbcommand.Parameters.Add("@transport", OleDbType.VarChar, 250);
            myoledbcommand.Parameters["@transport"].Value = Convert.ToInt32(comboBox5.Text);

            myOleDbConnection.Open();
            myoledbcommand.ExecuteNonQuery();
            myOleDbConnection.Close();

            loadUsage();
        }

    }
}
